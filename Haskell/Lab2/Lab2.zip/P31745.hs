main :: IO ()
main = return ()

flatten :: [[Int]] -> [Int]
flatten x = foldl (++) [] x

myLength :: String -> Int 
myLength

firstWord :: String -> String
firstWord xs = takeWhile (/= ' ') $ dropWhile (==' ') xs
